// 67d7842dbbe25473c3c32b93c0da8047785f30d78e8a024de1b57352245f9689
/* autopilot_tech.h */
/*
 * __VIVADO_HLS_COPYRIGHT-INFO__ 
 *
 * $Id$
 */


#ifndef _AUTOPILOT_TECH_H_
#define _AUTOPILOT_TECH_H_

#include "ap_cint.h"
#include "ap_utils.h"

#endif /* #ifndef _AUTOPILOT_TECH_H_ */



